export enum Pagina {
  Inicio,
  Login,
  Admin,
  Atendente,
  Candidato,
  ErroBD,
}

export const USUARIO_ADMIN = 'Administrador';
export const SENHA_ADMIN = 'estacio2025';